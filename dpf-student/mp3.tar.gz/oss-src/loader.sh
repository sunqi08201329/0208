# 2010.3.5

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:../libmad-0.15.0b/.libs/
# export LD_LIBRARY_PATH=
